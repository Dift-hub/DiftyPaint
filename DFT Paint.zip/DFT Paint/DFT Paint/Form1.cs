﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DFT_Paint
{
    public partial class Form1 : Form
    {
        Bitmap pic;
        Bitmap pic1;
        string mode;
        Color CurrentColor = Color.Black;
        bool isPressed = false;
        Point CurrentPoint;
        Point PrevPoint;
        Graphics g;
        Bitmap button2_Click;
        

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
            pic = new Bitmap(1080, 1080);
            pic1 = new Bitmap(1080, 1080);
            SolidBrush b = new SolidBrush(Color.White);
            Graphics.FromImage(pic).FillRectangle(b,0,0,pic.Width,pic.Height);
            Graphics.FromImage(pic1).FillRectangle(b, 0, 0, pic1.Width, pic.Height);
            mode = "Линия";
            panel1.BackgroundImage = pic;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult D = colorDialog1.ShowDialog();
            if (D == System.Windows.Forms.DialogResult.OK)
            {
                CurrentColor = colorDialog1.Color;
            }
        }
                 
        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isPressed = false;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isPressed)
            {
                PrevPoint = CurrentPoint;
                CurrentPoint = e.Location;
                for_paint();

            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isPressed = true;
            CurrentPoint = e.Location;
        }
        private void файлToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void СохранитьToolstripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            pic.Save(saveFileDialog1.FileName);
        }

        private void for_paint()
        {
            Pen p = new Pen(CurrentColor, trackBar1.Value);
            p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
            p.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            g.DrawLine(p, PrevPoint, CurrentPoint);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void сохранитьToolStripMenuItem_Click_2(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
                pic.Save(saveFileDialog1.FileName);

        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            {
                pic = (Bitmap)Image.FromFile(openFileDialog1.FileName);
                
            }

        }



        private void button4_Click(object sender, EventArgs e)
        {
            mode = "Линия";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            mode = "Прямоугольник";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            mode = "Овал";
        
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
        }
    }
    
}
